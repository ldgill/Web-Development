// code for ro sham bo 


// get the input from user
// randomly choose computer's weapon
// determine winner of the round
// show results of one round

// TODO add UI to allow user to choose number of rounds to determine game
// TODO keep score, and declare game winner




// global variables neded in multiple functions
var playerWeapon;
var computerWeapon;
var winner;


// play the game - called from buttons' onclick
function play(weapon) {
  
  playerWeapon = weapon;
  chooseComputerWeapon();
  determineWinner();
  showResults();
}




// select the computer's weapon. give each weapon 1 out of 3 chance 
function chooseComputerWeapon() {
  
    
}

// logic to determine winner - assume tie, then check for actual winner
function determineWinner() {
  
}


function showResults() {
 // console.log(playerWeapon  + " " + computerWeapon + "->"+winner);
  
}
